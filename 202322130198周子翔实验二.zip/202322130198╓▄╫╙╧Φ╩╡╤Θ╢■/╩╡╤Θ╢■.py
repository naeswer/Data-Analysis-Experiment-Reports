import chardet
import pandas as pd

# 检测文件编码
with open('D:/Pokemon.csv', 'rb') as file:
    rawdata = file.read()
    result = chardet.detect(rawdata)
    encoding = result['encoding']

# 使用检测到的编码读取数据集
df = pd.read_csv('D:/Pokemon.csv', encoding=encoding)

print('数据基本信息：')
df.info()

# 查看数据集行数和列数
rows, columns = df.shape

if rows < 100 and columns < 20:
    # 短表数据（行数少于100且列数少于20）查看全量数据信息
    print('数据全部内容信息：')
    print(df.to_csv(sep='\t', na_rep='nan'))
else:
    # 长表数据查看数据前几行信息
    print('数据前几行内容信息：')
    print(df.head().to_csv(sep='\t', na_rep='nan'))

# 查看每列唯一值数量
unique_values = df.nunique()
print('每列唯一值数量：')
print(unique_values)

# 检查重复行
duplicate_rows = df[df.duplicated()]
print('重复行数：', len(duplicate_rows))

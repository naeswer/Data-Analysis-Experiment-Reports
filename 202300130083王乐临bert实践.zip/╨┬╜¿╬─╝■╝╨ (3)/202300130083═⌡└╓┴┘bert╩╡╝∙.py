import torch
import torch.nn as nn
import csv
import os
from torch.utils.data import Dataset, DataLoader
from transformers import BertTokenizer, BertModel


# 1. 全连接层模型（FCModel）
class FCModel(nn.Module):
    def __init__(self):
        super(FCModel, self).__init__()
        self.fc1 = nn.Linear(768, 256)  # BERT输出768维特征
        self.fc2 = nn.Linear(256, 1)    # 二分类输出
        self.relu = nn.ReLU()
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        x = self.fc1(x)
        x = self.relu(x)
        x = self.fc2(x)
        x = self.sigmoid(x)
        return x


# 2. 本地MRPC数据集加载类（核心优化：增加异常行容错）
class LocalMRPCDataset(Dataset):
    def __init__(self, data_path, tokenizer):
        self.data = []
        self.tokenizer = tokenizer
        self.invalid_rows = 0  # 统计无效行数，方便排查问题

        print(f"开始读取MRPC数据集：{data_path}")
        # 关键优化1：用制表符严格分隔，处理可能的多空格/空行
        with open(data_path, 'r', encoding='utf-8-sig', errors='ignore') as f:
            # 用csv.reader指定制表符分隔，避免因分隔符不规范拆分错误
            reader = csv.reader(f, delimiter='\t', skipinitialspace=True)
            next(reader)  # 跳过表头（表头格式：Quality\t#1 ID\t#2 ID\t#1 String\t#2 String）
            
            # 关键优化2：逐行检查列数，跳过不足5列的异常行
            for line_num, row in enumerate(reader, start=2):  # line_num从2开始（表头是1行）
                # 过滤空行（拆分后只有空字符串的行）
                if not [col for col in row if col.strip()]:
                    self.invalid_rows += 1
                    print(f"  跳过空行：第{line_num}行")
                    continue
                
                # 过滤列数不足5列的异常行（官方MRPC每行应5列）
                if len(row) < 5:
                    self.invalid_rows += 1
                    print(f"  跳过异常行（列数不足5列）：第{line_num}行，拆分后列数：{len(row)}，内容：{row}")
                    continue
                
                # 提取有效数据（只取前5列，避免多余列干扰）
                try:
                    label = int(row[0].strip())  # 第0列：标签（0/1）
                    sentence1 = row[3].strip()   # 第3列：句子1
                    sentence2 = row[4].strip()   # 第4列：句子2
                    
                    # 过滤句子为空的行
                    if not sentence1 or not sentence2:
                        self.invalid_rows += 1
                        print(f"  跳过无效行（句子为空）：第{line_num}行，句子1：{sentence1}，句子2：{sentence2}")
                        continue
                    
                    self.data.append((sentence1, sentence2, label))
                except Exception as e:
                    # 捕获其他异常（如标签无法转int）
                    self.invalid_rows += 1
                    print(f"  跳过错误行（处理失败）：第{line_num}行，错误原因：{str(e)}，内容：{row[:5]}")

        # 打印数据集读取总结，方便确认数据质量
        print(f"MRPC数据集读取完成：有效样本数={len(self.data)}，无效行数={self.invalid_rows}")
        if len(self.data) == 0:
            raise ValueError("未加载到任何有效MRPC样本！请检查数据集文件是否正确，或重新下载官方MRPC数据集。")

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        sentence1, sentence2, label = self.data[idx]
        combined_sentence = f"{sentence1} [SEP] {sentence2}"  # 适配BERT输入
        return combined_sentence, label


# 3. 核心路径配置（确保路径正确）
LOCAL_BERT_PATH = "C:/Users/30140/Desktop/bert-base-uncased"  # BERT本地文件夹（需含5个核心文件）
MRPC_TRAIN_PATH = "C:/Users/30140/Desktop/msr_paraphrase_train.txt"  # MRPC训练集

# 路径验证（提前报错，避免后续问题）
if not os.path.exists(LOCAL_BERT_PATH):
    raise FileNotFoundError(f"BERT模型路径不存在：{LOCAL_BERT_PATH}\n请确认路径正确，或重新下载bert-base-uncased的5个核心文件（config.json、pytorch_model.bin等）。")
if not os.path.exists(MRPC_TRAIN_PATH):
    raise FileNotFoundError(f"MRPC数据集路径不存在：{MRPC_TRAIN_PATH}\n请确认路径正确，或重新解压官方MRPC数据集。")


# 4. 初始化组件（本地加载，无网络）
print("\n=== 初始化本地BERT组件 ===")
# 加载分词器（强制本地，不访问Hub）
tokenizer = BertTokenizer.from_pretrained(LOCAL_BERT_PATH, local_files_only=True)
# 加载BERT模型（强制本地）
bert_model = BertModel.from_pretrained(LOCAL_BERT_PATH, local_files_only=True)
print("BERT分词器和模型加载完成")


# 5. 加载本地MRPC数据集（已增加容错）
print("\n=== 加载本地MRPC数据集 ===")
mrpc_dataset = LocalMRPCDataset(
    data_path=MRPC_TRAIN_PATH,
    tokenizer=tokenizer
)
train_loader = DataLoader(dataset=mrpc_dataset, batch_size=16, shuffle=True)
print(f"DataLoader创建完成：批次大小={16}，总批次数={len(train_loader)}")


# 6. 设备配置（GPU/CPU自动适配）
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"\n=== 设备配置 ===")
print(f"当前运行设备：{device}")
bert_model = bert_model.to(device)
fc_model = FCModel().to(device)


# 7. 优化器与损失函数
bert_optimizer = torch.optim.Adam(bert_model.parameters(), lr=1e-5)
fc_optimizer = torch.optim.Adam(fc_model.parameters(), lr=1e-4)
criterion = torch.nn.BCELoss()  # 二分类交叉熵损失


# 8. 准确率计算函数
def binary_accuracy(predictions, labels):
    rounded_preds = torch.round(predictions)  # 概率四舍五入（0.5为界）
    correct = (rounded_preds == labels).float()  # 统计正确样本数
    accuracy = correct.sum() / len(correct)  # 计算批次准确率
    return accuracy


# 9. 训练函数（保持不变）
def train_epoch(epoch_idx):
    epoch_loss = 0.0
    epoch_acc = 0.0
    total_samples = 0

    # 设为训练模式（启用 dropout）
    bert_model.train()
    fc_model.train()

    print(f"\n=== 开始第{epoch_idx}轮训练 ===")
    for batch_idx, (sentences, labels) in enumerate(train_loader):
        # 数据部署到设备
        labels = labels.to(device).float()  # BCELoss要求标签为float类型

        # 分词处理（本地完成，无网络）
        encodings = tokenizer(
            sentences,
            return_tensors="pt",
            padding=True,  # 自动补全到批次最长长度
            truncation=True,  # 超长句子截断
            max_length=128  # 限制最大长度，避免显存溢出
        )
        encodings = {k: v.to(device) for k, v in encodings.items()}  # 编码结果部署到设备

        # 梯度清零（避免累计梯度）
        bert_optimizer.zero_grad()
        fc_optimizer.zero_grad()

        # 模型前向传播
        bert_outputs = bert_model(**encodings)  # BERT输出（含pooler_output）
        pooler_features = bert_outputs.pooler_output  # 提取句子对的聚合特征（768维）
        predictions = fc_model(pooler_features).squeeze()  # 全连接层输出预测概率（压缩维度）

        # 计算损失与准确率
        loss = criterion(predictions, labels)
        acc = binary_accuracy(predictions, labels)

        # 反向传播（求梯度）与参数更新
        loss.backward()
        bert_optimizer.step()
        fc_optimizer.step()

        # 累计统计信息
        batch_size = labels.size(0)
        epoch_loss += loss.item() * batch_size
        epoch_acc += acc.item() * batch_size
        total_samples += batch_size

        # 每10个批次打印一次进度
        if (batch_idx + 1) % 10 == 0:
            print(f"  批次 {batch_idx + 1}/{len(train_loader)} | 损失：{loss.item():.4f} | 准确率：{acc.item():.4f}")

    # 计算本轮平均损失与准确率
    avg_loss = epoch_loss / total_samples
    avg_acc = epoch_acc / total_samples
    print(f"=== 第{epoch_idx}轮训练完成 ===")
    print(f"  平均损失：{avg_loss:.4f} | 平均准确率：{avg_acc:.4f}")
    return avg_loss, avg_acc


# 10. 启动训练（3轮，可根据需要调整）
print("\n=== 开始训练任务 ===")
num_epochs = 3
for epoch in range(1, num_epochs + 1):
    train_epoch(epoch)
print("\n=== 所有训练轮次完成！ ===")
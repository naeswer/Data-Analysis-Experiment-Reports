import pandas as pd
import chardet

# 检测文件编码
with open('D:/data.csv', 'rb') as file:
    raw_data = file.read()
    result = chardet.detect(raw_data)
    encoding = result['encoding']

print(f'文件编码格式为: {encoding}')

# 使用检测到的编码加载数据
df = pd.read_csv('D:/data.csv', encoding='GB2312')

print('数据基本信息：')
df.info()

# 查看数据集行数和列数
rows, columns = df.shape

if rows < 100 and columns < 20:
    # 短表数据（行数少于100且列数少于20）查看全量数据信息
    print('数据全部内容信息：')
    print(df.to_csv(sep='\t', na_rep='nan'))
else:
    # 长表数据查看数据前几行信息
    print('数据前几行内容信息：')
    print(df.head().to_csv(sep='\t', na_rep='nan'))

# 1. 随机采样 10% 的数据
sampled_data_1 = df.sample(frac=0.1, random_state=42)

# 2. 过滤出 from_city 为'通辽'且 to_city 为'北京'的数据
filtered_data_1 = df[(df['from_city'] == '通辽') & (df['to_city'] == '北京')]

# 3. 过滤出 traffic 大于 50000000000 且 bandwidth 小于 150000000000 的数据
filtered_data_2 = df[(df['traffic'] > 50000000000) & (df['bandwidth'] < 150000000000)]

print('随机采样 10% 的数据：')
print(sampled_data_1.to_csv(sep='\t', na_rep='nan'))
print('from_city 为通辽且 to_city 为北京的数据：')
print(filtered_data_1.to_csv(sep='\t', na_rep='nan'))
print('traffic 大于 50000000000 且 bandwidth 小于 150000000000 的数据：')
print(filtered_data_2.to_csv(sep='\t', na_rep='nan'))

# 保存采样和过滤后的数据
sampled_data_1.to_csv('D:/sampled_data_1.csv', index=False)
filtered_data_1.to_csv('D:/filtered_data_1.csv', index=False)
filtered_data_2.to_csv('D:/filtered_data_2.csv', index=False)

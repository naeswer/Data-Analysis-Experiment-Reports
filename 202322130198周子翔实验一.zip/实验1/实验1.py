# 1. 库导入与数据读取（解决编码问题）
import pandas as pd
from pandas import DataFrame
import numpy as np

# 本地文件读取（指定GBK编码，兼容Windows）
primitive_data = pd.read_csv("D:/data.csv", encoding='gbk')  # 若报错换 encoding='gb18030'

# 2. 数据清洗（删除空行+过滤条件）
primitive_data_1 = primitive_data.dropna(how='any')  # 删除含空值的行
data_before_filter = primitive_data_1
data_after_filter_1 = data_before_filter.loc[data_before_filter["traffic"] != 0]  # traffic≠0
data_after_filter_2 = data_after_filter_1.loc[data_after_filter_1["from_level"] == '一般节点']  # from_level=一般节点
data_before_sample = data_after_filter_2
columns = data_before_sample.columns  # 保留原始列名

# 3. 三种采样方法（完整输出50个样本，同时保存为CSV）
## （1）加权采样（to_level权重：一般节点1，网络核心5）
weight_sample = data_before_sample.copy()
weight_sample['weight'] = weight_sample['to_level'].apply(lambda x: 1 if x == '一般节点' else 5)
weight_sample_finish = weight_sample.sample(n=50, weights='weight')[columns]
print("="*50 + " 加权采样完整结果（50个样本） " + "="*50)
print(weight_sample_finish)
weight_sample_finish.to_csv("D:/加权采样结果.csv", index=False, encoding='gbk')  # 保存为CSV

## （2）随机采样
random_sample_finish = data_before_sample.sample(n=50)[columns]
print("\n" + "="*50 + " 随机采样完整结果（50个样本） " + "="*50)
print(random_sample_finish)
random_sample_finish.to_csv("D:/随机采样结果.csv", index=False, encoding='gbk')  # 保存为CSV

## （3）分层采样（一般节点17个，网络核心33个）
ybjd = data_before_sample.loc[data_before_sample['to_level'] == '一般节点']
wlhx = data_before_sample.loc[data_before_sample['to_level'] == '网络核心']
stratified_sample_finish = pd.concat([ybjd.sample(17), wlhx.sample(33)])
print("\n" + "="*50 + " 分层采样完整结果（50个样本） " + "="*50)
print(stratified_sample_finish)
stratified_sample_finish.to_csv("D:/分层采样结果.csv", index=False, encoding='gbk')  # 保存为CSV

print("\n✅ 所有采样结果已完整输出，并保存到 D 盘根目录（3个CSV文件）")
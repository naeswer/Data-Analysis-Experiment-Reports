import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


def load_data():
    """读取D盘下的宝可梦数据集，自动适配编码格式"""
    file_path = "D:/Pokemon.csv"
    encodings = ['gbk', 'gb2312', 'gb18030', 'utf-8', 'latin-1']

    for encoding in encodings:
        try:
            data = pd.read_csv(file_path, encoding=encoding)
            print(f"✅ 数据集读取成功（使用编码：{encoding}）")
            print("原始数据形状：", data.shape)
            print("\n原始数据前5行：")
            print(data.head())
            print("\n各列数据类型：")
            print(data.dtypes)
            return data
        except UnicodeDecodeError:
            print(f"❌ 尝试编码 {encoding} 失败，继续重试...")
        except FileNotFoundError:
            print(f"❌ 未找到文件：{file_path}")
            print("请检查：")
            print("1. 文件是否真的在D盘指定路径下")
            print("2. 文件名是否为 Pokemon.csv（注意大小写和后缀）")
            print("3. 路径中是否有中文/特殊字符")
            return None
        except Exception as e:
            print(f"❌ 编码 {encoding} 读取异常：{e}")
            continue

    print("❌ 所有编码尝试均失败，无法读取文件！")
    return None


def clean_data(data):
    """执行完整的数据清洗流程"""
    # 预处理数值列，确保Attack为数值类型
    print("\n===== 预处理：修复数值列数据类型 =====")
    # 处理Attack列：转换为数值类型，无法转换的设为NaN后删除
    print(f"Attack列原始数据类型：{data['Attack'].dtype}")
    # 转换为数值型，非数值值转为NaN
    data['Attack'] = pd.to_numeric(data['Attack'], errors='coerce')
    # 删除Attack列为NaN的行
    attack_nan_count = data['Attack'].isnull().sum()
    if attack_nan_count > 0:
        print(f"发现{attack_nan_count}条Attack列非数值数据，已删除")
        data = data.dropna(subset=['Attack'])
    print(f"Attack列处理后数据类型：{data['Attack'].dtype}")

    # 1. 删除最后两行无意义数据
    print("\n===== 步骤1：删除最后两行无意义数据 =====")
    print("数据尾部10行：")
    print(data.tail(10))
    data = data.iloc[:-2]
    print(f"删除后数据形状：{data.shape}")

    # 2. 处理Type2列异常值（清空"273"）
    print("\n===== 步骤2：处理Type2列异常值 =====")
    print("Type2列唯一值（前20个）：")
    # 处理可能的空值显示问题
    unique_vals = data["Type 2"].unique()[:20]
    print([val if pd.notna(val) else "NaN" for val in unique_vals])
    # 先处理Type2列的NaN，避免筛选时出错
    data = data[~((data["Type 2"] == "273") | pd.isna(data["Type 2"]))]
    print(f"处理后数据形状：{data.shape}")

    # 3. 去除重复值
    print("\n===== 步骤3：去除重复值 =====")
    duplicate_count = data.duplicated().sum()
    print(f"重复值数量：{duplicate_count}")
    if duplicate_count > 0:
        print("重复数据：")
        print(data[data.duplicated()])
    data = data.drop_duplicates()
    print(f"去重后数据形状：{data.shape}")

    # 4. 处理Attack属性异常高值
    print("\n===== 步骤4：处理Attack属性异常值 =====")
    # 可视化Attack分布（识别异常值）
    plt.figure(figsize=(12, 5))
    plt.subplot(1, 2, 1)
    # 确保x轴和y轴都是数值型
    x_data = np.arange(len(data))
    y_data = data["Attack"].values
    plt.scatter(x_data, y_data, alpha=0.6)
    plt.title("Attack属性原始分布")
    plt.xlabel("数据索引")
    plt.ylabel("Attack值")

    # 用四分位距(IQR)计算异常值阈值
    Q1 = data["Attack"].quantile(0.25)
    Q3 = data["Attack"].quantile(0.75)
    IQR = Q3 - Q1
    upper_bound = Q3 + 1.5 * IQR
    print(f"Attack异常值阈值（上界）：{upper_bound:.2f}")

    # 查看并删除异常值
    abnormal_attack = data[data["Attack"] > upper_bound]
    print(f"\nAttack异常值数据（共{len(abnormal_attack)}条）：")
    if len(abnormal_attack) > 0:
        print(abnormal_attack[["Name", "Attack"]])
    data = data[data["Attack"] <= upper_bound]
    print(f"删除异常值后数据形状：{data.shape}")

    # 可视化处理后的Attack分布
    plt.subplot(1, 2, 2)
    plt.scatter(np.arange(len(data)), data["Attack"].values, alpha=0.6, color="green")
    plt.title("Attack属性清洗后分布")
    plt.xlabel("数据索引")
    plt.ylabel("Attack值")
    plt.tight_layout()
    plt.savefig("attack_distribution.png")
    plt.show()

    # 5. 修正generation与Legendary列置换问题
    print("\n===== 步骤5：修正列置换问题 =====")
    # 先确保两列存在且有数据
    if "Generation" in data.columns and "Legendary" in data.columns:
        print("修正前两列数据：")
        print(data[["Generation", "Legendary"]].head(10))

        # 交换两列值
        data["Generation"], data["Legendary"] = data["Legendary"].copy(), data["Generation"].copy()

        try:
            data["Legendary"] = data["Legendary"].map({True: 1, False: 0, 'True': 1, 'False': 0}).fillna(0).astype(int)
            data["Generation"] = data["Generation"].astype(bool)
        except Exception as e:
            print(f"数据类型转换警告：{e}，使用备选转换方式")
            data["Legendary"] = pd.to_numeric(data["Legendary"], errors='coerce').fillna(0).astype(int)
            data["Generation"] = data["Generation"].astype(str).map(
                {'True': True, 'False': False, '1': True, '0': False}).fillna(False)

        print("修正后两列数据：")
        print(data[["Generation", "Legendary"]].head(10))
    else:
        print("警告：Generation/Legendary列缺失，跳过列置换修正")

    return data


def verify_cleaned_data(data):
    """验证清洗后的数据质量"""
    print("\n===== 清洗结果验证 =====")
    print(f"最终清洗后数据形状：{data.shape}")
    print("\n各列数据类型：")
    print(data.dtypes)
    print("\n描述性统计：")
    print(data.describe())
    print("\n缺失值统计：")
    print(data.isnull().sum())

    data.to_csv("cleaned_pokemon.csv", index=False, encoding="utf-8-sig")
    print("\n✅ 清洗后的数据已保存为：cleaned_pokemon.csv（当前运行目录下）")


if __name__ == "__main__":
    raw_data = load_data()
    if raw_data is None:
        exit()

    cleaned_data = clean_data(raw_data)
    verify_cleaned_data(cleaned_data)
    print("\n🎉 数据清洗流程全部完成！")
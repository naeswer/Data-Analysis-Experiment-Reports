from transformers import AutoTokenizer, AutoModel
import pandas as pd
import numpy as np
import os
import torch
from torch import nn
import yaml



def code2RGB(s : str) -> list:
    red = s[1:3]
    green = s[3:5]
    blue = s[5:7]
    
    res = []
    res.append(int(red.lower(),16))
    res.append(int(green.lower(),16))
    res.append(int(blue.lower(),16))
    
    return res


def RGB2code(x):
    return None





class Classifier(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(768, 2048),
            nn.ReLU(),
            nn.Linear(2048, 3),
            nn.Sigmoid()  # 输出0-1，后续乘255映射到RGB(0-255)
        )
        self.loss_fn = nn.MSELoss()  # 预测RGB用MSE Loss
        
        
    def forward(self,x):
        """_summary_

        Args:
            x (tensor(256,768)): 经过BERT处理后得到的批量数据
        """
        x = self.net(x)
        
        # 最终x应为(batch_size,3)
        
        x = x * 255
        
        return x
    
    def Loss(self,x,tgt):
        return self.loss_fn(x,tgt)
    
    
    
def load_config(config_path="config.yaml"):
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)
        





if __name__ == "__main__":
    config = load_config()
    

    tokenizer = AutoTokenizer.from_pretrained(config["model"]["model_name"])

    model = AutoModel.from_pretrained(config["model"]["model_name"])

    for param in model.parameters():
        param.requires_grad = False  # 禁用梯度，彻底冻结
    # 将BERT设为评估模式
    model.eval()


    df = pd.read_csv(config["train"]["csv_path"],encoding="utf-8")
    df_array = np.array(df)#将pandas读取的数据转化为ndarray
    df_list = df_array.tolist()#将数组转化为list of list,形如:[['蝋色', '#2f271d'], ['紫黒', '#1d1626']]
    print("===============================================")
    color_names = [n[0] for n in df_list]
    color_id = [n[1] for n in df_list]

    color_rgb = [code2RGB(l) for l in color_id]
    color_rgb = torch.tensor(color_rgb, dtype=torch.float32) #->tensor(number , 3)
    
    inputs = tokenizer(color_names, padding="longest", truncation=True, return_tensors="pt")
    
    x = model(**inputs).pooler_output
    
    
    classifier = Classifier()
    
    optimizer = torch.optim.Adam(classifier.parameters(), lr=config["train"]["learning_rate"])
    choice = input("是否要重新训练?(y/n): ")
    if choice == "y":
        for e in range(config["train"]["epoch"]):
            optimizer.zero_grad()
            
            out = classifier.forward(x)
            
            l = classifier.Loss(out,color_rgb)
            
            l.backward()
            
            optimizer.step()
            
            print(f"========epoch: {e} _ LOSS: {l}========")
            
        torch.save(model.state_dict(), 'model_weights.pth')
    elif choice == "n":
        model.load_state_dict(torch.load('model_weights.pth'))
    else:
        print("输错了")
        exit()

        
        
    print("=======================测试=======================")
    color = "大红色"
    color = tokenizer(color, return_tensors="pt")
    o = model(**color).pooler_output
    final = classifier.forward(o)
    print(final)
        
        
        
    



file_path = 'color.txt'

import chardet

encoding = "utf-8"


with open(file_path, 'r' , encoding=encoding) as file:
    # 执行文件操作，例如读取文件内容
    file_content = file.read()
    print(file_content)
    print(encoding)
    
file_content_x = file_content.replace("\n#", ",#")
print(file_content_x)

with open("color.csv",'w' , encoding=encoding) as f:
    f.write(file_content_x)


import torch
import numpy as np
from sklearn.metrics import accuracy_score, classification_report
from transformers import (
    BertTokenizer, 
    BertConfig, 
    BertForSequenceClassification,
    Trainer, 
    TrainingArguments,
    DataCollatorWithPadding
)
from datasets import load_dataset

# -------------------------- 1. 全局配置（可按需修改）--------------------------
class Config:
    # 模型配置
    model_name = "bert-base-uncased"  # 预训练模型名称（小写处理，适配中文需换bert-base-chinese）
    num_labels = 2  # 分类任务类别数（IMDB二分类：正面/负面）
    max_seq_len = 128  # 文本最大长度（显存不足可改64）
    # 训练配置
    batch_size = 8  # 批次大小（GPU≥6GB可设16，4GB设8，CPU设4）
    epochs = 3  # 训练轮数（二分类3轮足够，避免过拟合）
    learning_rate = 2e-5  # BERT微调关键学习率（1e-5~3e-5）
    weight_decay = 0.01  # 权重衰减（防止过拟合）
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # 自动检测GPU/CPU
    output_dir = "./bert_imdb_model"  # 模型保存路径
    logging_dir = "./bert_logs"  # 日志保存路径

config = Config()

# -------------------------- 2. 加载并预处理数据集（已修复：移除idx列）--------------------------
# 加载IMDB数据集（已通过国内镜像成功下载，无需手动修改）
dataset = load_dataset("imdb")
print("数据集结构：", dataset)  # 确认列：text、label（无idx）

# 加载BERT分词器（与模型名称严格匹配）
tokenizer = BertTokenizer.from_pretrained(config.model_name)

# 定义数据预处理函数：分词、截断、填充
def preprocess_function(examples):
    return tokenizer(
        examples["text"],  # 输入文本字段
        truncation=True,  # 超过max_seq_len自动截断
        padding="max_length",  # 填充到固定长度
        max_length=config.max_seq_len,
        return_tensors="pt"  # 返回PyTorch张量
    )

# 对数据集应用预处理（修改：只删除存在的text列，移除idx）
tokenized_dataset = dataset.map(
    preprocess_function,
    batched=True,  # 批量处理，提升效率
    remove_columns=["text"]  # 仅删除text列（label列保留作为标签）
)

# 转换为PyTorch格式（指定核心列：input_ids/attention_mask/label）
tokenized_dataset.set_format("torch", columns=["input_ids", "attention_mask", "label"])

# 划分训练集和验证集（从train拆分10%作为验证集）
tokenized_dataset = tokenized_dataset["train"].train_test_split(test_size=0.1)
train_dataset = tokenized_dataset["train"]  # 训练集：22500条
val_dataset = tokenized_dataset["test"]    # 验证集：2500条

# 处理测试集（修改：同样只删除text列）
test_dataset = dataset["test"].map(
    preprocess_function,
    batched=True,
    remove_columns=["text"]
).set_format("torch", columns=["input_ids", "attention_mask", "label"])

# 数据整理器：确保批次内张量对齐（兼容动态填充）
data_collator = DataCollatorWithPadding(tokenizer=tokenizer)

# -------------------------- 3. 加载BERT模型与配置 --------------------------
# 加载预训练模型（自动适配分类任务，加载对应Config）
model = BertForSequenceClassification.from_pretrained(
    config.model_name,
    num_labels=config.num_labels
).to(config.device)

# 查看模型状态（可选，确认设备和结构）
print(f"模型设备：{config.device}")
print(f"模型结构：{model}")

# -------------------------- 4. 定义评估函数与训练参数 --------------------------
# 评估函数：计算准确率、精确率、召回率
def compute_metrics(eval_pred):
    logits, labels = eval_pred  # logits：模型输出分数，labels：真实标签
    predictions = np.argmax(logits, axis=1)  # 取概率最大的类别
    return {
        "accuracy": accuracy_score(labels, predictions),
        "classification_report": classification_report(
            labels, predictions, target_names=["负面", "正面"], output_dict=True
        )
    }

# 训练参数配置（适配新手，简化日志和保存逻辑）
training_args = TrainingArguments(
    output_dir=config.output_dir,
    logging_dir=config.logging_dir,
    num_train_epochs=config.epochs,
    per_device_train_batch_size=config.batch_size,
    per_device_eval_batch_size=config.batch_size * 2,  # 评估批次可翻倍
    learning_rate=config.learning_rate,
    weight_decay=config.weight_decay,
    warmup_steps=500,  # 学习率热身（避免初始梯度爆炸）
    logging_steps=100,  # 每100步打印一次训练日志
    evaluation_strategy="epoch",  # 每轮结束后评估
    save_strategy="epoch",  # 每轮结束后保存模型
    load_best_model_at_end=True,  # 训练结束加载最优模型（基于验证集准确率）
    metric_for_best_model="accuracy",  # 最优模型判定指标：准确率
    fp16=torch.cuda.is_available(),  # GPU支持时开启混合精度训练（加速）
    report_to="none",  # 不使用额外日志工具（简化流程）
    overwrite_output_dir=True  # 覆盖已有模型文件（方便重复训练）
)

# 初始化Trainer（封装训练循环，无需手动写反向传播）
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=val_dataset,
    data_collator=data_collator,
    compute_metrics=compute_metrics
)

# -------------------------- 5. 模型训练与评估 --------------------------
print("="*50)
print("开始训练（设备：{}）...".format(config.device))
trainer.train()

# 保存最优模型和Tokenizer（方便后续推理）
model.save_pretrained(config.output_dir)
tokenizer.save_pretrained(config.output_dir)
print(f"模型已保存至：{config.output_dir}")

# 测试集评估（输出最终性能）
print("="*50)
print("开始测试集评估...")
test_results = trainer.evaluate(eval_dataset=test_dataset)
print(f"测试集准确率：{test_results['eval_accuracy']:.4f}")

# 打印详细分类报告
test_predictions = np.argmax(trainer.predict(test_dataset).predictions, axis=1)
print("测试集分类报告：")
print(classification_report(
    test_dataset["label"].numpy(),
    test_predictions,
    target_names=["负面", "正面"],
    digits=4
))

# -------------------------- 6. 模型推理（使用训练好的模型预测新文本） --------------------------
print("="*50)
print("开始推理示例...")

# 加载训练好的模型和Tokenizer
loaded_tokenizer = BertTokenizer.from_pretrained(config.output_dir)
loaded_model = BertForSequenceClassification.from_pretrained(config.output_dir).to(config.device)
loaded_model.eval()  # 切换到评估模式（禁用Dropout）

# 待预测文本（中英文均可，英文效果更好，中文需换bert-base-chinese模型）
test_texts = [
    "This movie is amazing! The acting is great and the plot is fascinating.",  # 正面
    "Worst film I've ever seen. The story is boring and the characters are stupid.",  # 负面
    "It's an okay movie, not the best but not bad either.",  # 中性
    "这部电影太精彩了，演员演技在线，剧情跌宕起伏，强烈推荐！"  # 中文（需换模型才准确）
]

# 文本预处理
inputs = loaded_tokenizer(
    test_texts,
    truncation=True,
    padding=True,
    max_length=config.max_seq_len,
    return_tensors="pt"
).to(config.device)

# 推理（禁用梯度计算，加速+省显存）
with torch.no_grad():
    outputs = loaded_model(**inputs)
    logits = outputs.logits
    predictions = torch.argmax(logits, dim=1).cpu().numpy()  # 转换为CPU格式

# 输出结果
label_map = {0: "负面", 1: "正面"}
for text, pred in zip(test_texts, predictions):
    print(f"文本：{text}")
    print(f"预测结果：{label_map[pred]}")
    print("-"*50)

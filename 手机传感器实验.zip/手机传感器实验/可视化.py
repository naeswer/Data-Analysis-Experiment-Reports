import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.fft import fft, fftfreq

# 1. Data reading
df = pd.read_csv('TotalAcceleration.csv')

# 2. Data overview
print("Basic Information:")
print(df.info())
print("\nFirst 5 rows:")
print(df.head())
print("\nStatistical Description:")
print(df.describe())

# 3. Data processing
# Calculate total acceleration (three-axis synthesis)
df['total_acc'] = np.sqrt(df['x']**2 + df['y']**2 + df['z']**2)

# Calculate rolling mean for smoothing
window_size = 10
df['x_smooth'] = df['x'].rolling(window=window_size, center=True).mean()
df['y_smooth'] = df['y'].rolling(window=window_size, center=True).mean()
df['z_smooth'] = df['z'].rolling(window=window_size, center=True).mean()
df['total_smooth'] = df['total_acc'].rolling(window=window_size, center=True).mean()

# 4. Visualization of three-axis acceleration over time
plt.figure(figsize=(15, 10))

# Subplot 1: Three-axis acceleration separated
plt.subplot(3, 2, 1)
plt.plot(df['seconds_elapsed'], df['x'], label='X-axis', alpha=0.6, linewidth=0.5)
plt.plot(df['seconds_elapsed'], df['x_smooth'], label='X-axis (Smoothed)', linewidth=1.5, color='blue')
plt.xlabel('Time (s)')
plt.ylabel('Acceleration (m/s²)')
plt.title('X-axis Acceleration Over Time')
plt.legend()
plt.grid(True, alpha=0.3)

plt.subplot(3, 2, 3)
plt.plot(df['seconds_elapsed'], df['y'], label='Y-axis', alpha=0.6, linewidth=0.5, color='orange')
plt.plot(df['seconds_elapsed'], df['y_smooth'], label='Y-axis (Smoothed)', linewidth=1.5, color='orange')
plt.xlabel('Time (s)')
plt.ylabel('Acceleration (m/s²)')
plt.title('Y-axis Acceleration Over Time')
plt.legend()
plt.grid(True, alpha=0.3)

plt.subplot(3, 2, 5)
plt.plot(df['seconds_elapsed'], df['z'], label='Z-axis', alpha=0.6, linewidth=0.5, color='green')
plt.plot(df['seconds_elapsed'], df['z_smooth'], label='Z-axis (Smoothed)', linewidth=1.5, color='green')
plt.xlabel('Time (s)')
plt.ylabel('Acceleration (m/s²)')
plt.title('Z-axis Acceleration Over Time')
plt.legend()
plt.grid(True, alpha=0.3)

# Subplot 2: Three-axis acceleration combined
plt.subplot(3, 2, 2)
plt.plot(df['seconds_elapsed'], df['x_smooth'], label='X-axis', linewidth=1.5, color='blue')
plt.plot(df['seconds_elapsed'], df['y_smooth'], label='Y-axis', linewidth=1.5, color='orange')
plt.plot(df['seconds_elapsed'], df['z_smooth'], label='Z-axis', linewidth=1.5, color='green')
plt.xlabel('Time (s)')
plt.ylabel('Acceleration (m/s²)')
plt.title('Three-axis Acceleration Comparison')
plt.legend()
plt.grid(True, alpha=0.3)

# Subplot 3: Total acceleration over time
plt.subplot(3, 2, 4)
plt.plot(df['seconds_elapsed'], df['total_acc'], alpha=0.6, linewidth=0.5, color='red')
plt.plot(df['seconds_elapsed'], df['total_smooth'], linewidth=2, color='red')
plt.xlabel('Time (s)')
plt.ylabel('Total Acceleration (m/s²)')
plt.title('Total Acceleration Over Time')
plt.grid(True, alpha=0.3)

# Mark high acceleration regions
high_acc_threshold = df['total_smooth'].mean() + df['total_smooth'].std()
high_acc_mask = df['total_smooth'] > high_acc_threshold
plt.fill_between(df['seconds_elapsed'], 0, df['total_smooth'], 
                 where=high_acc_mask, color='red', alpha=0.3, label='High Acceleration Region')
plt.legend()

# Subplot 4: Frequency spectrum analysis
plt.subplot(3, 2, 6)
# FFT analysis for total acceleration
n = len(df['total_acc'])
sampling_rate = n / df['seconds_elapsed'].max()
yf = fft(df['total_acc'].fillna(0))
xf = fftfreq(n, 1/sampling_rate)[:n//2]

plt.plot(xf[:100], 2.0/n * np.abs(yf[:n//2])[:100])
plt.xlabel('Frequency (Hz)')
plt.ylabel('Amplitude')
plt.title('Acceleration Frequency Spectrum (First 100 Frequencies)')
plt.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('acceleration_analysis_comprehensive.png', dpi=300, bbox_inches='tight')
plt.show()

# 5. Feature extraction and analysis (保留分析部分)
print("\n=== Acceleration Feature Analysis ===")

# Calculate basic statistical features
print(f"Data Duration: {df['seconds_elapsed'].max():.2f} seconds")
print(f"Number of Samples: {len(df)}")
print(f"Average Sampling Rate: {len(df)/df['seconds_elapsed'].max():.2f} Hz")

print(f"\nAcceleration Statistics per Axis:")
print(f"X-axis: Mean={df['x'].mean():.2f}, Std={df['x'].std():.2f}, Range=[{df['x'].min():.2f}, {df['x'].max():.2f}]")
print(f"Y-axis: Mean={df['y'].mean():.2f}, Std={df['y'].std():.2f}, Range=[{df['y'].min():.2f}, {df['y'].max():.2f}]")
print(f"Z-axis: Mean={df['z'].mean():.2f}, Std={df['z'].std():.2f}, Range=[{df['z'].min():.2f}, {df['z'].max():.2f}]")

print(f"\nTotal Acceleration Statistics:")
print(f"Mean: {df['total_acc'].mean():.2f} m/s²")
print(f"Standard Deviation: {df['total_acc'].std():.2f} m/s²")
print(f"Maximum: {df['total_acc'].max():.2f} m/s²")
print(f"Minimum: {df['total_acc'].min():.2f} m/s²")

# Detect high acceleration events
# 修复：添加high_acc_events的定义
high_acc_events = df[high_acc_mask]
print(f"\nNumber of High Acceleration Events: {len(high_acc_events)}")
if len(high_acc_events) > 0:
    print(f"Average Intensity of High Acceleration Events: {high_acc_events['total_acc'].mean():.2f} m/s²")
    print(f"Longest High Acceleration Duration: {(high_acc_events['seconds_elapsed'].max() - high_acc_events['seconds_elapsed'].min()):.2f} seconds")

print("\n=== Analysis Complete ===")
print("Figure saved as: acceleration_analysis_comprehensive.png")